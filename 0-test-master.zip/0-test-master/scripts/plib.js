// Mechanical Warfare extra pallette lib.
// Lib by JerichoFletcher
module.exports = {
  frontColorHE: Color.valueOf("ffd385"),
  backColorHE: Color.valueOf("b6573a"),
  frontColorAP: Color.valueOf("fbff85"),
  backColorAP: Color.valueOf("b68f3a"),
  frontColorLava: Color.valueOf("ffddcc"),
  backColorLava: Color.valueOf("ccaa99"),
  frontColorCyan: Color.valueOf("c4fdfd"),
  backColorCyan: Color.valueOf("4be3ca"),
  frontColorPurple: Color.valueOf("f8c5fd"),
  backColorPurple: Color.valueOf("d699dc"),
  
  engineColorCyan: Color.valueOf("7efdfd"),
  engineColorPurple: Color.valueOf("e487ed"),
  
  fireAuraFlame: Color.valueOf("ffaa44"),
}
