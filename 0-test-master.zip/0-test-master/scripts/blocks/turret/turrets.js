// Aegis
const aegis = extendContent(ItemTurret, "aegis", {});

// Ghost
require("blocks/turret/ghost")

// Incandescence
require("blocks/turret/incandescence")

// Nighthawk
require("blocks/turret/nighthawk")

//Voltmeter
require("blocks/turret/voltmeter")

// Blow
require("blocks/turret/blow")

// Quake
require("blocks/turret/quake")

// Seism
require("blocks/turret/seism")
